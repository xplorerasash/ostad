import 'package:flutter/material.dart';


import 'CRUD/widget/Crud.dart';
import 'class_1.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'flutter api',
      home: Crud() ,
    );
  }
}
