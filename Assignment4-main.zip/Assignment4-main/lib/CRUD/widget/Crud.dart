import 'package:flutter/material.dart';
import 'package:restapii/CRUD/productcontoller.dart';
import 'package:restapii/CRUD/widget/product_card.dart';

class Crud extends StatefulWidget {
  const Crud({super.key});

  @override
  State<Crud> createState() => _CrudState();
}

class _CrudState extends State<Crud> {
  ProductController productController = ProductController();

  @override
  void initState() {
    super.initState();
    productController.fetchProduct().then((_) {
      setState(() {});
    });
  }

  productDialog({
    String? id,
    String? name,
    String? img,
    int? qty,
    int? uniPrice,
    int? totalPrice,
    required bool isUpdate,
  }) {
    TextEditingController productNameController = TextEditingController(
      text: name,
    );
    TextEditingController productIMGController = TextEditingController(
      text: img,
    );
    TextEditingController productQTYController = TextEditingController(
      text: qty != null ? qty.toString() : '',
    );
    TextEditingController productUnitPriceController = TextEditingController(
      text: uniPrice != null ? uniPrice.toString() : '',
    );
    TextEditingController productTotalPriceController = TextEditingController(
      text: totalPrice != null ? totalPrice.toString() : '',
    );
    showDialog(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: Text(isUpdate ? "Update Product" : "Add Product"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: productNameController,
                  decoration: InputDecoration(
                    labelText: 'Product Name',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: productIMGController,
                  decoration: InputDecoration(
                    labelText: 'Product img',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: productQTYController,
                  decoration: InputDecoration(
                    labelText: 'Product qty',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: productUnitPriceController,
                  decoration: InputDecoration(
                    labelText: 'Product unit price',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: productTotalPriceController,
                  decoration: InputDecoration(
                    labelText: 'Product total price',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(height: 10),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('Cancle'),
                    ),

                    ElevatedButton(
                      onPressed: () async {
                        isUpdate
                            ? productController.UpdateProduct(
                          id.toString(),
                          productNameController.text,
                          productIMGController.text,
                          int.parse(productQTYController.text),
                          int.parse(productUnitPriceController.text),
                          int.parse(productTotalPriceController.text),
                        )
                            : await productController.createProduct(
                            productNameController.text,
                            productIMGController.text,
                            int.parse(productQTYController.text),
                            int.parse(productUnitPriceController.text),
                            int.parse(productTotalPriceController.text)
                        );

                        Navigator.pop(context);
                        setState(() {});
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text('Save'),
                    ),
                  ],
                ),
              ],
            ),
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Product CRUD"),
        backgroundColor: Colors.orange,
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          childAspectRatio: 0.8,
        ),
        itemCount: productController.products.length,
        itemBuilder: (context, index) {
          var product = productController.products[index];
          return ProductCard(
            product: product,
            onDelete: () {
              productController.DeleteProduct(product.sId.toString()).then((
                  value,) async {
                if (value) {
                  await productController.fetchProduct();
                  setState(() {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(SnackBar(content: Text('Product Deleted')));
                  });
                } else {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(SnackBar(content: Text('Something wrong...')));
                }
              });
            },
            onEdit: () {
              productDialog(
                name: product.productName,
                img: product.img,
                id: product.sId,
                qty: product.qty,
                uniPrice: product.unitPrice,
                totalPrice: product.totalPrice,
                isUpdate: true,
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          productDialog(isUpdate: false);
        },
        child: Icon(Icons.add),
      ),
    );
  }

}