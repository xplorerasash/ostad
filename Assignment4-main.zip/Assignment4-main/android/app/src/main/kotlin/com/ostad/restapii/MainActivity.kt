package com.ostad.restapii

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
